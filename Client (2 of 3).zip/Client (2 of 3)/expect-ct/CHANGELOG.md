# Changelog

## Unreleased
### Added
- TypeScript type definitions. See [helmetjs/helmet#188](https://github.com/helmetjs/helmet/issues/188)
- Additional package metadata (bugs, homepage, etc)

### Changed
- Updated documentation

Changes in versions 0.1.1 and below can be found in [Helmet's changelog](https://github.com/helmetjs/helmet/blob/master/CHANGELOG.md).

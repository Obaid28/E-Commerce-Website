
0.0.2 / 2011-04-25 
==================

  * Fixed clobbering of length var [reported by MIB]

0.0.1 / 2010-09-06 
==================

  * Initial release

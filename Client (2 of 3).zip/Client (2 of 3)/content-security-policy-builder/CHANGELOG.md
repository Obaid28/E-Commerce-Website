# Changelog

## 2.1.0 - 2019-06-13
### Added
- Added TypeScript type definitions. See [#6](https://github.com/helmetjs/content-security-policy-builder/issues/6)
- Created a changelog

### Changed
- Excluded useless files from npm package

This changelog was started after the release of version 2.1.0.

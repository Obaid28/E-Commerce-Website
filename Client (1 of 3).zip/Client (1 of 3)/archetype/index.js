module.exports = require('./src').Archetype;

module.exports.CastError = require('./src').CastError;
module.exports.matchType = require('./src/helpers/matchType');
module.exports.to = require('./src/to');

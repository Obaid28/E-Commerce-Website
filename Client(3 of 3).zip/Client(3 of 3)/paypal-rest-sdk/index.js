module.exports = require('./lib/paypal-rest-sdk.js')();
